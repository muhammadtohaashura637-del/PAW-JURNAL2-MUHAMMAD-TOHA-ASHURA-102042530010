<?php
// Koneksi database menggunakan MySQL XAMPP (Port 3306, user root, password kosong)
$host = '127.0.0.1';
$port = 3306;
$user = 'root';
$pass = '';
$db   = 'paw_jurnal2_lms';

try {
    $conn = new mysqli($host, $user, $pass, $db, $port);
    $conn->set_charset('utf8mb4');
    
    // Opsional: Pesan sukses koneksi (bisa dihapus jika tidak diperlukan)
    // echo "Koneksi database berhasil!";
    
} catch (mysqli_sql_exception $e) {
    http_response_code(503);
    exit('Koneksi database gagal. Cek MySQL sudah menyala, database.sql sudah di-import, dan isi connect.php sudah benar.');
}
?>
