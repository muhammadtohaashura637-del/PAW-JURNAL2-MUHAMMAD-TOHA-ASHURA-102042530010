<?php
require 'functions.php';
require 'connect.php';

// TODO 1 (RINGKASAN)
// Hitung jumlah baris di tabel mata_kuliah, materi, dan tugas,
// lalu hitung juga tugas yang statusnya 'Aktif'.
// Simpan hasilnya ke empat variabel di bawah ini (gunakan COUNT, bukan mengambil semua baris).

// 1. Hitung jumlah mata kuliah
$query_mk = "SELECT COUNT(*) AS total FROM mata_kuliah";
$result_mk = mysqli_query($conn, $query_mk);
$jumlah_mata_kuliah = mysqli_fetch_assoc($result_mk)['total'];

// 2. Hitung jumlah materi
$query_materi = "SELECT COUNT(*) AS total FROM materi";
$result_materi = mysqli_query($conn, $query_materi);
$jumlah_materi = mysqli_fetch_assoc($result_materi)['total'];

// 3. Hitung jumlah tugas
$query_tugas = "SELECT COUNT(*) AS total FROM tugas";
$result_tugas = mysqli_query($conn, $query_tugas);
$jumlah_tugas = mysqli_fetch_assoc($result_tugas)['total'];

// 4. Hitung jumlah tugas yang statusnya 'Aktif'
$query_tugas_aktif = "SELECT COUNT(*) AS total FROM tugas WHERE status = 'Aktif'";
$result_tugas_aktif = mysqli_query($conn, $query_tugas_aktif);
$jumlah_tugas_aktif = mysqli_fetch_assoc($result_tugas_aktif)['total'];

$pilihan_mk = pilihan_mata_kuliah($conn);

$judul = 'Beranda';
require 'header.php';
?>
<p class="eyebrow">Learning Management System</p>
<h1 class="hero">Kelola perkuliahan dalam satu tempat.</h1>
<p class="muted">Pengelolaan mata kuliah, materi pembelajaran, dan tugas.</p>

<div class="stats">
    <a class="card stat" href="mata_kuliah.php">
        <b><?= (int) $jumlah_mata_kuliah ?></b>
        <span>Mata kuliah</span>
    </a>
    <a class="card stat" href="materi.php">
        <b><?= (int) $jumlah_materi ?></b>
        <span>Materi</span>
    </a>
    <a class="card stat" href="tugas.php">
        <b><?= (int) $jumlah_tugas ?></b>
        <span>Tugas</span>
    </a>
    <a class="card stat" href="tugas.php?status=Aktif">
        <b><?= (int) $jumlah_tugas_aktif ?></b>
        <span>Tugas aktif</span>
    </a>
</div>

<h2>Mata kuliah tersedia</h2>
<?php if (count($pilihan_mk) === 0): ?>
    <p class="empty">Belum ada mata kuliah.</p>
<?php else: ?>
    <div class="card list">
        <?php foreach ($pilihan_mk as $id => $nama): ?>
            <a class="list-item" href="mata_kuliah.php?aksi=detail&id=<?= (int) $id ?>"><?= h($nama) ?></a>
        <?php endforeach ?>
    </div>
<?php endif ?>
<?php require 'footer.php'; ?>